print('Hello, world')
