def hello(name):
    """
    A friendly function.
    """
    print ("Hello, " + name + "!")

# the customary greeting
hello("universe")
