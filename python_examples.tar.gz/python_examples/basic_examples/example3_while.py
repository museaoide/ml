print("------------------")
C = -20
dC = 5
while C <= 40:
  F = (9.0/5)*C + 32
  print(C, F)
  C = C + dC
print("------------------")

