#! /usr/bin/env python

print ("Welcome to Python!")
