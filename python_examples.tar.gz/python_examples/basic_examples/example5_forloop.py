degrees = [0, 10, 20, 40, 100]
for C in degrees:
  print("list element:", C)
print("The degrees list has", len(degrees), "elements")
