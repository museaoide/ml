def greet(name):
  """
  A friendly function
  """
  print ("Hello, " + name + "!")
	 
# the costomary greeting

def bla(name):
  print ("bla, " + name + "!")

greet("world")
  